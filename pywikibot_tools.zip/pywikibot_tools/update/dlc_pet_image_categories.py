'''
This python script pulls a list of pages that are both `Pets` and `DLC`
then associates specific categories to those image files
so they show up in various DPL queries on the wiki.
'''

import os
import re
import sys
import time
import random
import pywikibot

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import config.constants as constants

# Apply Pywikibot config from constants
sys.path.append(constants.ADDITIONAL_PATHS["PWB"])
site = pywikibot.Site()

# Paths
output_file_path = os.path.join(constants.OUTPUT_DIRECTORY, "Pywikibot", "pywikibot_updatePetImage.txt")
debug_log_path = os.path.join(constants.DEBUG_DIRECTORY, "pywikibot", "pywikibot_updatePetImage_debug.txt")
os.makedirs(os.path.dirname(debug_log_path), exist_ok=True)

# Constants
BASE_CATEGORIES = {"Sun Haven assets", "Pet images", "DLC pet images"}
UNKNOWN_PACK_CATEGORY = "Unknown pack images"
PACK_SUFFIX = " pack images"
UPLOAD_SLEEP_INTERVAL = constants.PWB_SETTINGS["SLEEP_INTERVAL"]

def log_debug(message):
    with open(debug_log_path, "a", encoding="utf-8") as debug_file:
        debug_file.write(message + "\n")

def write_section_header(file, header):
    file.write(f"\n### {header} ###\n")

def get_category_titles(page):
    return set(cat.title().replace("Category:", "") for cat in page.categories())

def preload_pages_batched(titles, batch_size=25, sleep_interval=2):
    pages = {}
    for i in range(0, len(titles), batch_size):
        batch = titles[i:i+batch_size]
        batch_pages = site.preloadpages([pywikibot.Page(site, title) for title in batch])
        for page in batch_pages:
            pages[page.title()] = page
        log_debug(f"🛠️ Preloaded {len(batch)} pages, sleeping {sleep_interval}s...")
        time.sleep(sleep_interval)
    return pages

def preload_file_pages_batched(file_titles, batch_size=25, sleep_interval=2):
    pages = {}
    for i in range(0, len(file_titles), batch_size):
        batch = file_titles[i:i+batch_size]
        batch_pages = site.preloadpages([pywikibot.FilePage(site, f"File:{title}") for title in batch])
        for page in batch_pages:
            pages[page.title(with_ns=False)] = page
        log_debug(f"🛠️ Preloaded {len(batch)} files, sleeping {sleep_interval}s...")
        time.sleep(sleep_interval)
    return pages

def get_category_members(category_name):
    try:
        cat = pywikibot.Category(site, f"Category:{category_name}")
        return set(page.title() for page in cat.articles())
    except Exception as e:
        log_debug(f"Error fetching category {category_name}: {e}")
        return set()

def main():
    try:
        pets_pages = get_category_members("Pets")
        time.sleep(5)
        dlc_pages = get_category_members("DLC")
        time.sleep(5)

        common_pages = sorted(pets_pages & dlc_pages)
        if not common_pages:
            log_debug("No matching pages found between 'Pets' and 'DLC'.")
            return

        print(f"✅ Found {len(common_pages)} pages that are both 'Pets' and 'DLC' categories.")
        print("📦 Gathering category information from matched pages...")

        file_titles = [f"{title}.png" for title in common_pages]
        page_map = preload_pages_batched(common_pages)
        file_map = preload_file_pages_batched(file_titles)

        upload_counter = 0
        missing_images = []
        missing_base = []
        mismatch_pack = []
        unknown_pack = []
        missing_caption = []

        for title in common_pages:
            file_name = f"{title}.png"
            file_page = file_map.get(file_name)
            original_page = page_map.get(title)

            if file_page is None or not file_page.exists():
                missing_images.append(file_name)
                continue

            image_categories = get_category_titles(file_page)
            original_categories = get_category_titles(original_page)
            updated_text = file_page.text
            modified = False
            fix_log_parts = []

            # --- Caption ---
            if not re.search(r'^\s*==\s*Caption\s*==\s*$', updated_text, re.IGNORECASE | re.MULTILINE):
                caption_block = f"==Caption==\n[[{title}|{title}]]\n\n"
                updated_text = caption_block + updated_text
                modified = True
                fix_log_parts.append("Caption section")

            # --- Licensing ---
            missing = BASE_CATEGORIES - image_categories
            has_games_template = "{{License|game}}" in updated_text
            if has_games_template:
                if not re.search(r'==\s*Licensing\s*==\s*\n\{\{Games\}\}', updated_text, re.IGNORECASE):
                    updated_text = re.sub(r'(\{\{Games\}\})', r'==Licensing==\n\1', updated_text, count=1, flags=re.IGNORECASE)
                    modified = True
                    fix_log_parts.append("Inserted Licensing header above {{License|game}}")
            else:
                updated_text += "\n\n==Licensing==\n{{License|game}}"
                modified = True
                fix_log_parts.append("Added Licensing section with {{License|game}}")

            cat_lines = []
            if "DLC pet images" in missing:
                cat_lines.append("[[Category:DLC pet images]]")
                fix_log_parts.append("DLC category")
            if "Pet images" in missing:
                cat_lines.append("[[Category:Pet images]]")
                fix_log_parts.append("Pet category")
            if cat_lines:
                updated_text += "\n" + "\n".join(cat_lines)
                modified = True

            # --- Pack category from pet page ---
            pack_category = None
            for cat in original_categories:
                if cat.endswith("pack") and cat.lower() != "unknown dlc pack":
                    pack_category = cat
                    break
            if pack_category:
                pack_image_category = f"{pack_category} images"
                if pack_image_category not in image_categories:
                    updated_text = updated_text.rstrip() + f"\n[[Category:{pack_image_category}]]"
                    modified = True
                    fix_log_parts.append(f"Added [[Category:{pack_image_category}]]")

                # Always check for creation, even if already present in image
                image_cat_page = pywikibot.Page(site, f"Category:{pack_image_category}")
                if not image_cat_page.exists():
                    try:
                        image_cat_page.text = f"{{{{category}}}}\n[[Category:{pack_category}]]"
                        image_cat_page.save(summary=f"Creating image category for {pack_category}")
                        log_debug(f"📁 Created category: [[Category:{pack_image_category}]]")
                        log_debug(f"🕒 Sleeping for {UPLOAD_SLEEP_INTERVAL} seconds after saving [[Category:{pack_image_category}]], {time.strftime('%Y-%m-%d %H:%M:%S')}")
                        time.sleep(UPLOAD_SLEEP_INTERVAL + random.uniform(1.0, 2.0))
                    except Exception as e:
                        log_debug(f"❌ Failed to create category page [[Category:{pack_image_category}]]: {e}")

            # --- Save the page if needed ---
            if modified and updated_text.strip() != file_page.text.strip():
                file_page.text = updated_text
                try:
                    file_page.save(summary="Updated image page: added missing caption, licensing, and categories")
                    log_debug(f"🔧 Fixed {file_name}: " + " + ".join(fix_log_parts))
                    upload_counter += 1
                    log_debug(f"🕒 Sleeping for {UPLOAD_SLEEP_INTERVAL} seconds after saving {file_name}, {time.strftime('%Y-%m-%d %H:%M:%S')}")
                    time.sleep(UPLOAD_SLEEP_INTERVAL + random.uniform(1.0, 2.0))
                except Exception as e:
                    log_debug(f"❌ Failed to save {file_name}: {e}")
                    time.sleep(10)  # Backoff after failure
                    if missing:
                        missing_base.append(f"{file_name}: missing {', '.join(sorted(missing))}")
                    if not re.search(r'^\s*==\s*Caption\s*==\s*$', updated_text, re.IGNORECASE | re.MULTILINE):
                        missing_caption.append(file_name)

            # --- Other status checks ---
            if UNKNOWN_PACK_CATEGORY in image_categories:
                unknown_pack.append(file_name)

            if pack_category:
                expected = f"{pack_category} images"
                if expected not in image_categories:
                    mismatch_pack.append(f"{file_name}: has no match for '{expected}' from pet page")

            if (
                not missing and
                UNKNOWN_PACK_CATEGORY not in image_categories and
                re.search(r'^\s*==\s*Caption\s*==\s*$', updated_text, re.IGNORECASE | re.MULTILINE) and
                pack_category and f"{pack_category} images" in updated_text
            ):
                log_debug(f"✅ {file_name} passed all checks.")

        with open(output_file_path, "w", encoding="utf-8") as out:
            if missing_images:
                write_section_header(out, "Missing Images")
                out.write("\n".join(missing_images) + "\n")
            if missing_base:
                write_section_header(out, "Missing a Base Category")
                out.write("\n".join(missing_base) + "\n")
            if mismatch_pack:
                write_section_header(out, "Mis-match Pack")
                out.write("\n".join(mismatch_pack) + "\n")
            if unknown_pack:
                write_section_header(out, "Unknown Pack")
                out.write("\n".join(unknown_pack) + "\n")
            if missing_caption:
                write_section_header(out, "Missing Caption Section")
                out.write("\n".join(missing_caption) + "\n")

    except Exception as e:
        log_debug(f"Unexpected error in main: {e}")
        print("⚠️ An error occurred. Check the debug log for details.")

if __name__ == "__main__":
    main()
